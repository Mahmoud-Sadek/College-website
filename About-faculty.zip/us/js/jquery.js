$(document).ready(function(){


$(".gear-check").click(function(){
    $(".color-option").fadeToggle();
});

//change theme color

    var colorLi = $(".color-option ul li");
    colorLi
        .eq(0).css("backgroundColor","#E41B17").end()
        .eq(1).css("backgroundColor","#D813D0").end()
        .eq(2).css("backgroundColor","#101DD2").end()
        .eq(3).css("backgroundColor","#D2C510");
        
        colorLi.click(function()
                      {
                        $("link[href*='theme']").attr("href",$(this).attr("data-value"));
                        console.log( $(this).attr("data-value"))
                                    
                      });
});

//looding screen
$(window).load(function()
               {
                
                
                $(".loading-overlay .spinner").fadeOut(2000,
                function(){
                    $(this).parent().fadeOut(2000,
                function(){
                $(this).remove();
                $("body").css("overflow","auto");
                });
                });
               });
                
//scroll
var scrollButton = $("#scroll-top");
$(window).scroll(function()
                 {
                    //console.log($(this).scrollTop())
                    if ($(this).scrollTop() >= 700) {
                        //code
                        scrollButton.show();
                    }else{
                        scrollButton.hide();
                    }
                    });
                    scrollButton.click(function()
                                       {
                                        $("html,body").animate({scrollTop:0},600);
                                        });
                    //Nice scroll
$(document).ready(

  function() { 

    $("html").niceScroll();

  }

);