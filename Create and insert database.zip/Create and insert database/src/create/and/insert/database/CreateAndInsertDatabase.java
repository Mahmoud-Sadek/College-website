/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package create.and.insert.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Mahmoud
 */
public class CreateAndInsertDatabase {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            openConnection();
            createTable();
            studentData student = new studentData();
            student.setId("1");
            student.setFirstName("Mahmoud");
            student.setMiddleName("Mohamed");
            student.setLastName("sadek");
            student.setEmail("mahmoud.sadek@gmail.com");
            student.setPassword("2237917");
            student.setMobile("01020488243");
            student.setAddress("shbine");
            student.setDepartment("CS");
            student.setGender("male");
            student.setNationalId("123456789011345");
            student.setYear("3");
            insert(student);
            System.out.println(checkData(student.getEmail(), student.getPassword()));
           closeConnection(); 
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(CreateAndInsertDatabase.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(CreateAndInsertDatabase.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    static PreparedStatement state;
    static Connection connection;
    public static void openConnection() throws ClassNotFoundException, SQLException {
        Class.forName("com.mysql.jdbc.Driver");

        System.out.println("Driver loaded");
        // Connect to a database
        connection = DriverManager.getConnection("jdbc:mysql://localhost/test33", "root", "");

        System.out.println("Database connected");
        System.out.println("+++++++++++++++++++++++++++++++++++++++");
    }

    
    public static void insert(studentData student) throws SQLException {

 
            Statement statement;
            statement = connection.createStatement();

            state = (PreparedStatement) connection.prepareStatement("insert into login values(?,?,?,?,?,?,?,?,?,?,?,?)");
            state.setString(1, student.getId());
            state.setString(2, student.getFirstName());
            state.setString(3, student.getMiddleName());
            state.setString(4, student.getLastName());
            state.setString(5, student.getYear());
            state.setString(6, student.getDepartment());
            state.setString(7, student.getPassword());
            state.setString(8, student.getEmail());
            state.setString(9, student.getNationalId());
            state.setString(10, student.getMobile());
            state.setString(11, student.getGender());
            state.setString(12, student.getAddress());
            state.executeUpdate();
            
    }
    public static void createTable() throws SQLException {

 
            Statement statement;
            statement = connection.createStatement();

            state = (PreparedStatement) connection.prepareStatement("create table login "
                    + "(id varchar(5), first_name varchar(20), middle_name varchar(20), last_name varchar(20),"
                    + " year varchar(1), department varchar(4), password varchar(20), email varchar(30),"
                    + " national_id varchar(20), mobile varchar(12), gender varchar(5), address varchar(30))");

            state.executeUpdate();
            
    }

    public static boolean checkData(String email, String password) throws SQLException {
        Statement statement = connection.createStatement();

        // Execute a statement
        ResultSet resultSet = statement.executeQuery("SELECT * FROM `login`");

        ResultSetMetaData rsMetaData = resultSet.getMetaData();

        // Iterate through the result and print the student names   
        while (resultSet.next()) {
            String pass = resultSet.getString(7);
            String emails = resultSet.getString(8);
            if(pass.equals(password)&&emails.equals(email)){
                return true;
            }
        }
        return false;
    }

    public static void closeConnection() throws SQLException {
        connection.close();
    }
    
}
