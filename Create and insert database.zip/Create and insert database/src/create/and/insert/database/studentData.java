/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package create.and.insert.database;

/**
 *
 * @author Mahmoud
 */
public class studentData {

    public String getId() {
        return Id;
    }

    public void setId(String Id) {
        this.Id = Id;
    }
    private String Id;
    private String FirstName;
    private String MiddleName;
    private String LastName;
    private String Year;
    private String Department;
    private String Password;
    private String Email;
    private String NationalId;
    private String Mobile;
    private String Gender;
    private String Address;

    public void setFirstName(String FirstName) {
        this.FirstName = FirstName;
    }

    public void setMiddleName(String MiddleName) {
        this.MiddleName = MiddleName;
    }

    public void setLastName(String LastName) {
        this.LastName = LastName;
    }

    public void setYear(String Year) {
        this.Year = Year;
    }

    public void setDepartment(String Department) {
        this.Department = Department;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public void setNationalId(String NationalId) {
        this.NationalId = NationalId;
    }

    public void setMobile(String Mobile) {
        this.Mobile = Mobile;
    }

    public void setGender(String Gender) {
        this.Gender = Gender;
    }

    public void setAddress(String Address) {
        this.Address = Address;
    }

    public String getFirstName() {
        return FirstName;
    }

    public String getMiddleName() {
        return MiddleName;
    }

    public String getLastName() {
        return LastName;
    }

    public String getYear() {
        return Year;
    }

    public String getDepartment() {
        return Department;
    }

    public String getPassword() {
        return Password;
    }

    public String getEmail() {
        return Email;
    }

    public String getNationalId() {
        return NationalId;
    }

    public String getMobile() {
        return Mobile;
    }

    public String getGender() {
        return Gender;
    }

    public String getAddress() {
        return Address;
    }
    
}
